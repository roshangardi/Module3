package com.capgemini.web.csrm.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class PlayerBean implements Serializable{
	private int playerId;
	private String playerName;
	private LocalDate dateOfBirth;
	private String country;
	private String battingStyle;
	private int centuries;
	private int matches;
	private int totalRunScore;
	private int age;
	/**
	 * 
	 */
	public PlayerBean() {
		
	}
	/**
	 * @param playerName
	 * @param dateOfBirth
	 * @param country
	 * @param battingStyle
	 * @param centuries
	 * @param matches
	 * @param totalRunScore
	 */
	public PlayerBean(String playerName, LocalDate dateOfBirth, String country,
			String battingStyle, int centuries, int matches, int totalRunScore) {
		this.playerName = playerName;
		this.dateOfBirth = dateOfBirth;
		this.country = country;
		this.battingStyle = battingStyle;
		this.centuries = centuries;
		this.matches = matches;
		this.totalRunScore = totalRunScore;
	}
	/**
	 * @param playerId
	 * @param playerName
	 * @param dateOfBirth
	 * @param country
	 * @param battingStyle
	 * @param centuries
	 * @param matches
	 * @param totalRunScore
	 */
	public PlayerBean(int playerId, String playerName, LocalDate dateOfBirth,
			String country, String battingStyle, int centuries, int matches,
			int totalRunScore) {
		this.playerId = playerId;
		this.playerName = playerName;
		this.dateOfBirth = dateOfBirth;
		this.country = country;
		this.battingStyle = battingStyle;
		this.centuries = centuries;
		this.matches = matches;
		this.totalRunScore = totalRunScore;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBattingStyle() {
		return battingStyle;
	}
	public void setBattingStyle(String battingStyle) {
		this.battingStyle = battingStyle;
	}
	public int getCenturies() {
		return centuries;
	}
	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}
	public int getMatches() {
		return matches;
	}
	public void setMatches(int matches) {
		this.matches = matches;
	}
	public int getTotalRunScore() {
		return totalRunScore;
	}
	public void setTotalRunScore(int totalRunScore) {
		this.totalRunScore = totalRunScore;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "PlayerBean [playerId=" + playerId + ", playerName="
				+ playerName + ", dateOfBirth=" + dateOfBirth + ", country="
				+ country + ", battingStyle=" + battingStyle + ", centuries="
				+ centuries + ", matches=" + matches + ", totalRunScore="
				+ totalRunScore + "]";
	}
}
