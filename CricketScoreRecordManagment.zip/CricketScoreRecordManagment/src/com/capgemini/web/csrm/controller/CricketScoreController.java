package com.capgemini.web.csrm.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.web.csrm.dto.PlayerBean;
import com.capgemini.web.csrm.exception.CricketScoreException;
import com.capgemini.web.csrm.service.CricketServiceImpl;
import com.capgemini.web.csrm.service.ICricketService;

/**
 * Servlet implementation class CricketScoreController
 */
@WebServlet("/CricketScoreController")
public class CricketScoreController extends HttpServlet {
	
	private ICricketService cricketService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CricketScoreController() {
        cricketService=new CricketServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetPost(request, response);
	}
	protected void doGetPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		switch (action) {
		
		/*******************************
		 * Fetching All Players Data
		 *******************************/
		case "GetViewAllPlayers":
			try{
				rd=null;
				List<PlayerBean> playerBeans=cricketService.viewAllPlayers();
				for (PlayerBean playerBean : playerBeans) {
					playerBean.setAge(playerBean.getDateOfBirth().until(LocalDate.now()).getYears());
				}
				request.setAttribute("playerBeans", playerBeans);
				
				rd=request.getRequestDispatcher("ViewPlayers.jsp");
			}catch (CricketScoreException e) {
				request.setAttribute("errMsg", "Something went wrong trying to get Players Details. Reason: "+e.getMessage());
				rd=request.getRequestDispatcher("Error.jsp");
			}
			rd.forward(request, response);
			return;
			
		/*******************************
		 * Inserting Player Data
		 *******************************/	
		case "AddNewPlayer":
			try{
				rd=null;
				String playerName = request.getParameter("playerName");		
				String playerDob = request.getParameter("playerDob");		
				String team = request.getParameter("team");		
				String battingStyle = request.getParameter("battingStyle");		
				String centuries = request.getParameter("centuries");		
				String matches = request.getParameter("matches");		
				String totalRun = request.getParameter("totalRun");		
				DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate ld=LocalDate.parse(playerDob, formatter);
				PlayerBean playerBean= new PlayerBean();
				playerBean.setPlayerName(playerName);
				playerBean.setDateOfBirth(ld);
				playerBean.setCountry(team);
				playerBean.setBattingStyle(battingStyle+" Batsman");
				playerBean.setCenturies(Integer.parseInt(centuries));
				playerBean.setMatches(Integer.parseInt(matches));
				playerBean.setTotalRunScore(Integer.parseInt(totalRun));
				
				int id=cricketService.addPlayer(playerBean);
				request.setAttribute("id", id);
				rd=request.getRequestDispatcher("InsertSuccess.jsp");
							
			}catch(CricketScoreException e){
				request.setAttribute("errMsg", "Something went wrong trying to get Players Details. Reason: "+e.getMessage());
				rd=request.getRequestDispatcher("Error.jsp");
			}
			rd.forward(request, response);
			return;
			
		/****************************************************
		 * Forwarding the request using requestDispatcher
		 *****************************************************/
		case "NewPlayer":
			
				rd=null;
				List<String> teams=Arrays.asList("India","UK","Srilanka","Austrailia","Zimbawe");			
			
				request.setAttribute("teams", teams);
				rd=request.getRequestDispatcher("NewPlayer.jsp");
			
			rd.forward(request, response);
			return;
		default:
			break;
		}
		
	}
}
