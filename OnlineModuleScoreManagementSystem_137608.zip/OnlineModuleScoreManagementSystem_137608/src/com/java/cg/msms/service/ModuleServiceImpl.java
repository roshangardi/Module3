package com.java.cg.msms.service;

import java.util.ArrayList;

import com.java.cg.msms.dao.ModuleDAO;
import com.java.cg.msms.dao.ModuleDAOImpl;
import com.java.cg.msms.dto.TraineeBean;
import com.java.cg.msms.exception.TraineeException;



public class ModuleServiceImpl implements ModuleService {

	ModuleDAO service;
	public ModuleServiceImpl()
	{
		service=new ModuleDAOImpl();
	}
	@Override
	public int addDetails(TraineeBean bean) throws TraineeException {
		return service.addDetails(bean);
	}

	@Override
	public TraineeBean viewDetails(int id) throws TraineeException {
		return service.viewDetails(id);
	}
	@Override
	public ArrayList<Integer> getId() throws TraineeException {
		return service.getId();
	}

}
