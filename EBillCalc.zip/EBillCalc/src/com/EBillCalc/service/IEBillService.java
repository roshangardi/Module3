package com.EBillCalc.service;

import java.util.List;

import com.EBillCalc.bean.EBillBean;
import com.EBillCalc.exception.EBillException;

public interface IEBillService {

	public List<EBillBean> viewAllEBillData() throws EBillException; 

}
