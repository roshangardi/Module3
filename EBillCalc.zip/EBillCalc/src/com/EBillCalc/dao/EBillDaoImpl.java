package com.EBillCalc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.EBillCalc.bean.EBillBean;
import com.EBillCalc.exception.EBillException;
import com.EBillCalc.util.DbConnection;


public class EBillDaoImpl implements IEBillDao {

	@Override
	public List<EBillBean> viewAllEBillData() throws EBillException {
		
		List<EBillBean> list= new ArrayList<EBillBean>();
		Connection con=null;
		
		try {
			con=DbConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.viewAll);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next())
			{
				EBillBean bean= new EBillBean();
				bean.setConsumerNum(rst.getInt(1));
				bean.setConsumerName(rst.getString(2));
				bean.setAddress(rst.getString(3));
				
				list.add(bean);
			}
			
			
			con.close();
		} catch (EBillException e) {
			
			throw new EBillException("In Dao LAYER VIEWAlL METHOD"+e.getMessage());
		} catch (SQLException e) {
			
			throw new EBillException( "In Dao LAYER VIEWAlL METHOD"+e.getMessage());
		}
		
		return list;
	}

}
