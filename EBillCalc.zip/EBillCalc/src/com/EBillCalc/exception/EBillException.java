package com.EBillCalc.exception;

public class EBillException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7220764068434795852L;

	public EBillException(String message)
	{
		super(message);
	}
}
