package com.EBillCalc.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.EBillCalc.bean.EBillBean;
import com.EBillCalc.exception.EBillException;
import com.EBillCalc.service.EBillServiceImpl;
import com.EBillCalc.service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("*.obj")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		*/
		String path=request.getServletPath().trim();
		String targetPath="viewAll.jsp";
		String targetError="error.jsp";//this can be deleted also.
		IEBillService eBillService= new EBillServiceImpl();
		try {
			switch(path)
			{
			case"/viewAll.obj" : List<EBillBean> list= eBillService.viewAllEBillData();
								request.setAttribute("EBillList", list);
								break;
					
			}
		} catch (EBillException e) {
			
			targetPath="error.jsp";
			request.setAttribute("message", e.getMessage());
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetPath);
		rd.forward(request, response);
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
