package com.capgemini.divya.service;

import java.util.List;

import com.capgemini.divya.dto.GameBean;
import com.capgemini.divya.dto.UserBean;
import com.capgemini.divya.exception.GameException;

/*
 * Service Interface , declaring method signatures to be implemented in Service Impl class
 */
public interface IGameService {


	public void buyCard(UserBean user)
			throws GameException;
	
	public List<GameBean> getGameDetails() throws GameException;
}
