package com.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.constant.AllConstants;
import com.app.dto.FirmMaster;
import com.app.utility.DBUtil;
//Database Schema
/*Name          Null?    Type          
------------- -------- ------------- 
FIRM_ID       NOT NULL NUMBER(8)     
OWNER_NAME             VARCHAR2(100) 
BUSINESS_NAME          VARCHAR2(100) 
EMAIL                  VARCHAR2(80)  
MOBILE_NO              VARCHAR2(10)  
ISACTIVE               CHAR(1)       */
//DAO Implementation class
public class RegisterDAOImpl implements IRegisterDAO {
PreparedStatement pstmt=null;
PreparedStatement pstmtNew=null;
ResultSet resultSet=null;
	@Override
	//Inserting the record in the database
	public boolean addRecord(FirmMaster firm) {
		int isAdded=0;
		Connection conn=DBUtil.getConnection();
		try {
			pstmt=conn.prepareStatement(AllConstants.insert);
			System.out.println("***********"+firm);
			pstmt.setString(1,firm.getOwnerFirstName()+" "+firm.getOwnerMiddleName()+" "+firm.getOwnerLastName());
			pstmt.setString(2,firm.getBusinessName());
			pstmt.setString(3,firm.getEmail());
			pstmt.setString(4,firm.getMobileNo());
			pstmt.setString(5,"N");
			isAdded=pstmt.executeUpdate();
			pstmtNew=conn.prepareStatement(AllConstants.search);
			resultSet=pstmtNew.executeQuery();
			if(resultSet.next()){
				firm.setFirmId(resultSet.getInt(1));
			}
		} catch (SQLException e) {
			System.out.println("Some Error Occurred"+e);
			e.printStackTrace();
		}
		if(isAdded==1){
			return true;
		}
		else
		{
			return false;
		}
	}
	//Update the record to show the status as Y
	@Override
	public boolean updateRecord(String email) {
		int updateCount=0;
		try {
			pstmt=DBUtil.getConnection().prepareStatement(AllConstants.update);
			pstmt.setString(1,email);
			updateCount=pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Some Error Occurred"+e);
			e.printStackTrace();
		}
	return updateCount==1 ? true :false;
	}
	}

