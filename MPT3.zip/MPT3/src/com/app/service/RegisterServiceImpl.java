package com.app.service;

import com.app.dao.IRegisterDAO;
import com.app.dao.RegisterDAOImpl;
import com.app.dto.FirmMaster;
//implementation of the interface to pass the values to the business class
public class RegisterServiceImpl implements IRegisterService {

	@Override
	public boolean addRecord(FirmMaster firm) {
		IRegisterDAO registerdao=new RegisterDAOImpl();
		return registerdao.addRecord(firm);
	}

	@Override
	public boolean updateRecord(String email) {
		IRegisterDAO registerdao=new RegisterDAOImpl();
		return registerdao.updateRecord(email);
	}

}
