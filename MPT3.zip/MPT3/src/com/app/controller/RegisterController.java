package com.app.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.dto.FirmMaster;
import com.app.service.IRegisterService;
import com.app.service.RegisterServiceImpl;
/*The RegisterServlet Will Make use of the switch case to forward to
 * the requested URL*/
@WebServlet(urlPatterns={"/register","/success","/activate","/activated","/errorpage","/home","/add"})
public class RegisterController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Implement The Switch Case Here
		PrintWriter pw=null;
		pw=response.getWriter();
		IRegisterService registerservice=new RegisterServiceImpl();
		String urlPattern=request.getRequestURI();
		//Implementing the MVC Architecture to forward the code
		if(urlPattern.equals("/MPT3/register")){
	
			RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
			rd.forward(request,response);
			//Forwarding the URL
		}
		else if(urlPattern.equals("/MPT3/add"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("add.jsp");
			rd.forward(request,response);
		}
		else if(urlPattern.equals("/MPT3/success"))
		{	FirmMaster b1=(FirmMaster)request.getAttribute("customer");
			boolean isAdded=registerservice.addRecord(b1);
			pw.print("******"+b1);
			RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
			rd.forward(request,response);
		}
		else if(urlPattern.equals("/MPT3/activate"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("activate.jsp");
			rd.forward(request,response);
		}
		else if(urlPattern.equals("/MPT3/activated"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("activated.jsp");
			rd.forward(request,response);
		}
		else if(urlPattern.equals("/MPT3/errorpage"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("errorpage.jsp");
			rd.forward(request,response);
		}
		else if(urlPattern.equals("/MPT3/home"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			rd.forward(request,response);
		}
		else
		{
			//Some error Code
			pw.println("The Page You are Trying to access does not exists");
		}
	}

}
