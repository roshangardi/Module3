package com.rushi.service;

import java.util.List;

import com.rushi.bean.EBillBean;
import com.rushi.dao.EBillDaoImpl;
import com.rushi.dao.IBillDao;
import com.rushi.exception.BillException;

public class EBillServiceImpl implements IEBillService {
	private IBillDao billDao=new EBillDaoImpl();
	@Override
	public List<EBillBean> viewAllStudentDetails() throws BillException {
		return billDao.viewAllStudentDetails();
		
	}
	@Override
	public boolean insertBill(EBillBean bill) throws BillException {
		boolean result = billDao.insertBill(bill);
		return result;
	}
	@Override
	public boolean deleteBill(int consumerNum) throws BillException {
		IBillDao empDAO = new EBillDaoImpl();

		boolean isDeleted = empDAO.deleteBill(consumerNum);
		return (isDeleted);
	}
	@Override
	public EBillBean search(int consumerNum) throws BillException {
		EBillBean bill=new EBillBean();
		bill = billDao.search(consumerNum);
		return bill;
	}
}
