package com.rushi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.rushi.bean.EBillBean;
import com.rushi.exception.BillException;
import com.rushi.util.DbConnection;

public class EBillDaoImpl implements IBillDao {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;

	@Override
	public List<EBillBean> viewAllStudentDetails() throws BillException {
		List<EBillBean> list = new ArrayList<EBillBean>();

		try {
			conn = DbConnection.getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement(QuerryMapper.viewAll);
			ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				EBillBean bean = new EBillBean();
				bean.setConsumerNum(rst.getInt(1));
				bean.setConsumerName(rst.getString(2));
				bean.setAddress(rst.getString(3));
				list.add(bean);
			}
			conn.close();
		} catch (BillException e) {
			throw new BillException("In DAO Layer view Method "
					+ e.getMessage());

		} catch (SQLException e) {
			throw new BillException("In DAO Layer view Method "
					+ e.getMessage());

		}
		return list;
	}

	@Override
	public boolean insertBill(EBillBean bill) throws BillException {
		int result = 0;

		try (Connection conn = DbConnection.getConnection();) {
			preparedStatement = conn.prepareStatement(QuerryMapper.INSERTQUERY);
			preparedStatement.setInt(1, bill.getConsumerNum());
			preparedStatement.setString(2, bill.getConsumerName());
			preparedStatement.setString(3, bill.getAddress());

			result = preparedStatement.executeUpdate();

			if (result == 0) {
				return false;
			}
			return true;

		} catch (SQLException e) {
			throw new BillException("dao/sql/ERROR:" + e.getMessage());
		} catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		}

	}

	@Override
	public boolean deleteBill(int consumerNum) throws BillException {
		int records =0;
		boolean isUpdated=false;
		
		try(Connection connEmp = DbConnection.getConnection();			
				PreparedStatement preparedStatement=
						connEmp.prepareStatement(QuerryMapper.DELETEQUERY);){
									
			
			preparedStatement.setInt(1, consumerNum);
			
			records = preparedStatement.executeUpdate();
			
			if (records>0) {
				isUpdated = true;
			}
			
		}catch(SQLException sqlEx)
		{
			throw new BillException(sqlEx.getMessage());
		}
		return isUpdated;
	}
	
	
	

	@Override
	public EBillBean search(int consumerNum) throws BillException {
		EBillBean bill=new EBillBean();
		
		try(Connection connemp = DbConnection.getConnection();			
				PreparedStatement preparedStatement=connemp.prepareStatement(QuerryMapper.VIEWQUERRY);
							
				){
				preparedStatement.setInt(1, consumerNum);
			    ResultSet rsemps = preparedStatement.executeQuery();
				
			    while(rsemps.next()){
				
				bill.setConsumerNum(rsemps.getInt("consumer_num"));
				bill.setConsumerName(rsemps.getString("consumer_name"));
				bill.setAddress(rsemps.getString("address"));
							
				
				}
		}catch(SQLException sqlEx)
		{
			throw new BillException(sqlEx.getMessage());
		}
		return bill;
	}

}
