package com.rushi.exception;

public class BillException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5174325924927908039L;
	
	public BillException(){
		super();
	}
	public BillException(String message){
		super(message);
	}

}
