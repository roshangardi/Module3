package com.rushi.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rushi.bean.EBillBean;
import com.rushi.exception.BillException;
import com.rushi.service.EBillServiceImpl;
import com.rushi.service.IEBillService;

/**
 * Servlet implementation class BillServlet
 */
@WebServlet("*.obj")
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillServlet() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String path=request.getServletPath().trim();
		String targetPath=null;
		String targetError="error.jsp";
		IEBillService serviceBill=new EBillServiceImpl();
		try {
			switch(path){
			case "/viewAll.obj" : List<EBillBean> list=serviceBill.viewAllStudentDetails();
									request.setAttribute("billList", list);
									targetPath="viewAll.jsp";
									break;
			case "/insert.obj" : 
				EBillBean bean = new EBillBean();
				bean.setConsumerNum(Integer.parseInt(request.getParameter("consumerNum")));
				bean.setConsumerName(request.getParameter("consumerName"));
				bean.setAddress(request.getParameter("address"));
				IEBillService billService = new EBillServiceImpl();
				boolean val=billService.insertBill(bean);
				if(val)
				{
					targetPath="success.jsp";
				}
				else
				{
					 targetPath="error.jsp";
				}
				break;
			case "/delete.obj" :
				billService = new EBillServiceImpl();
				billService.deleteBill(Integer.parseInt(request.getParameter("id")));
				targetPath="viewAll.jsp";
				
			case "/view.obj":
				int ID=Integer.parseInt(request.getParameter("consumerNum"));
				try {
					
					bean = new EBillBean();
					billService = new EBillServiceImpl();
					bean= billService.search(ID);
				//session1.setAttribute("consumerDetails", list2);
					request.setAttribute("consumer", bean);
				targetPath="viewSuccess.jsp";
				} catch(Exception e){
					request.getSession().setAttribute("errorMsg", "Error occured in retreiving "+"data from db "+e.getMessage());
					response.sendRedirect("Error.jsp");
				}
				break;
			}
		} catch (BillException e) {
			targetPath="error.jsp";
			request.setAttribute("message", e.getMessage());
		}
		
		RequestDispatcher rd=request.getRequestDispatcher(targetPath);
		rd.forward(request, response);
	}

}
