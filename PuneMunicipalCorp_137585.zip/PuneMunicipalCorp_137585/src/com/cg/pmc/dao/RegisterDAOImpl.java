package com.cg.pmc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.pmc.bean.FirmMaster;
import com.cg.pmc.exception.FirmException;
import com.cg.pmc.util.DBUtil;

public class RegisterDAOImpl implements IRegisterDAO {

	public RegisterDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	public int generateFirmId() throws FirmException
	{
		
		int id=0;
		try(Connection con=DBUtil.getConnection())
		{
			
			Statement stm=con.createStatement();
			ResultSet res=stm.executeQuery("select seq_firm_master.nextVal from dual");
			if(res.next()==false){
				
				throw new FirmException("Could not generate id");}
			id=res.getInt(1);
			
		}
		catch(Exception e)
		{
			
			new FirmException(e.getMessage());
		}
		return id;
	}
	@Override
	public int registerFirm(FirmMaster f) throws FirmException {
		
		int id=0;
		try(Connection con=DBUtil.getConnection()){
			
			PreparedStatement pstm=con.prepareStatement("insert into firms_master(firm_id,owner_name,business_name,email,mobile_no,isactive) values(?,?,?,?,?,?)");
			f.setId(generateFirmId());
			f.setIsActive("N");
			pstm.setInt(1, f.getId());
			pstm.setString(2, f.getOwnerName());
			pstm.setString(3, f.getBusinessName());
			pstm.setString(4, f.getEmail());
			pstm.setString(5, f.getMobileNo());
			pstm.setString(6, f.getIsActive());
			pstm.execute();
			id=f.getId();                               
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}

}
