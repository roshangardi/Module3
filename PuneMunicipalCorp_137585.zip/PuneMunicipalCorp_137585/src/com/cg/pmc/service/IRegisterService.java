package com.cg.pmc.service;

import com.cg.pmc.bean.FirmMaster;
import com.cg.pmc.exception.FirmException;

public interface IRegisterService {

	public int registerFirm(FirmMaster f) throws FirmException;
}
