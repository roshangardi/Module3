package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.cg.mra.dto.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.util.DBUtil;


public class AccountDAOImpl implements IAccountDAO,DAOQueries {
	
	//logger
	static Logger myLogger =
			Logger.getLogger(AccountDAOImpl.class.getName());
	
//================================================================================================================
	
	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Get Account Details from Database
	 */

	
//=================================================================================================================

	@Override
	public Account getAccountDetails(String accountId) throws AccountException {
		
		//logger
		myLogger.info("Trying to Fetch Account Details");
		
		Account account = null;
		
		try(Connection con = DBUtil.getConnection()){
			
			
			
			PreparedStatement pstm = con.prepareStatement(GET_ACCOUNT_DETAILS);
			
			pstm.setString(1, accountId);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false){
				myLogger.error("Failed, account ID does not exists");
				throw new Exception("Given Account Id Does Not Exist. ID: "  + accountId);
			}
			
			account = new Account();
			
			account.setAccountId(res.getString(1));;
			account.setCustomerName(res.getString(2));
			account.setAccountType(res.getString(3));
			account.setAccountBalance(res.getDouble(4));
			
			
			
		}
		catch (Exception e)
		{
			myLogger.error("Could Not Get details due to wrong id . Exact Reason: " + e.getMessage());
			
			throw new AccountException(e.getMessage());
		}
		return account;
	}

	


//================================================================================================================
	
		/*
		 * Author: Gaurav Puniyani
		 * Emp ID: 137422	
		 * Date: 26th Oct 2017
		 * Description: Recharge Amount/Account Details to Database
		 */	
	
//============================================================================================================================
	
	@Override
	public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException {
		
		//logger
		myLogger.info("Trying to Add new Amount to Account");
		
		try(Connection con = DBUtil.getConnection()){
			
			PreparedStatement pstm = con.prepareStatement(RECHARGE_AMOUNT);
			
			pstm.setDouble(1, rechargeAmount);
			pstm.setString(2,accountId);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false){
				myLogger.error("Failed, account ID does not exists");
				throw new Exception("Given Account Id Does Not Exist");
			}
			
			
			pstm.execute();
		}
		catch(Exception e){
			
			myLogger.error("Could Not Get details due to wrong id/amount . Exact Reason: " + e.getMessage());
			throw new AccountException(e.getMessage());
		}
		return 0;
	}
}


