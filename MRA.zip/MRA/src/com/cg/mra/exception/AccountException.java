package com.cg.mra.exception;

//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Account Exception Class
	 */

	
//=================================================================================================================


public class AccountException extends Exception {

	public AccountException() {
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AccountException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
