package com.cg.bean;

public class BillDetails 
{
	private int bill_num;
	private int consumer_num;
	private float cur_reading;
	private int unitConsumed;
	private double netAmount;
	
	public BillDetails() {
		super();
			}
	
	public BillDetails(int bill_num, int consumer_num, float cur_reading,
			int unitConsumed, double netAmount) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
	}
	public int getBill_num() {
		return bill_num;
	}
	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public float getCur_reading() {
		return cur_reading;
	}
	public void setCur_reading(float cur_reading) {
		this.cur_reading = cur_reading;
	}
	public int getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	
	@Override
	public String toString() {
		return "BillDetails [bill_num=" + bill_num + ", consumer_num="
				+ consumer_num + ", cur_reading=" + cur_reading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ "]";
	}
	
	
		
}
