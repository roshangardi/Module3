package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.exception.ElectricityException;
import com.cg.service.ElectricityService;
import com.cg.service.ElectricityServiceImpl;

@WebServlet("/MainController")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 ServletConfig cg =null;
	 ElectricityService eserv =null;

    public MainController() {
        super();
        
    }

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
	}


	public void destroy() {
		
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		eserv = new ElectricityServiceImpl();
		Consumers cons =null;
		BillDetails bills =null;
		String action1 = request.getParameter("action");

		RequestDispatcher rd =null;
		
		HttpSession session=request.getSession(true);
		System.out.println(action1);
		if(action1!=null)
		{
			
			try
			{
				/********ShowLoginPage**************/
				
				if(action1.equals("ShowLoginPage"))
				{
					rd = request.getRequestDispatcher("Login.html");
					rd.forward(request, response);
				}
				/********End ShowLoginPage**************/
				
				
				/********ShowElecPage**************/
			
				if(action1.equals("ShowElecPage"))
				{
					
					PrintWriter pw = response.getWriter();
					eserv = new ElectricityServiceImpl();
					
					String unm = request.getParameter("txtUName");
					String pwd = request.getParameter("txtPwd");
					try 
					{
						
						if(unm.equals("admin") && pwd.equals("admin"))
						{
							RequestDispatcher rdSuccess = request.getRequestDispatcher("User_info.html");//forwarding to new servlet(dynamic page).
							rdSuccess.forward(request, response);
						}
						else
						{
							//RequestDispatcher rdFailure = request.getRequestDispatcher("htmls/Failure.html");//forwarding new html page(static page).
							//Instead of forwarding to failure page forward to login page.
							RequestDispatcher rdFailure = request.getRequestDispatcher("Login.html");
							rdFailure.forward(request, response);
						}
					} 
					catch (Exception e) 
					{			
						e.printStackTrace();
					}
				}
				/********End ShowElecPage**************/
				
				
				
				
				
				/********ShowLastPage**************/
				
				if(action1.equals("ShowLastPage"))
				{
					eserv = new ElectricityServiceImpl();
					cons = new Consumers();
					bills = new BillDetails();
					
					
					String consu = request.getParameter("cnum");
					int consumerNumber=Integer.parseInt(consu);
					String lread = request.getParameter("lastReading");
					int lastReading=Integer.parseInt(lread);
					String cread = request.getParameter("currentReading");
					int currReading=Integer.parseInt(cread);
					String cname= cons.getConsumer_name();
					
					int unitsconsumed = lastReading-currReading;
					double netAmount = (unitsconsumed *1.15)+100;
					
					bills.setConsumer_num(consumerNumber);
					bills.setCur_reading(currReading);
					bills.setNetAmount(netAmount);
					bills.setUnitConsumed(unitsconsumed);
					
					try 
					{
						if(eserv.insertDetails(bills) == 1)
						{
							RequestDispatcher rdSuccess = request.getRequestDispatcher("SuccessPage");
							session.setAttribute("UserNameObj", cname);
							session.setAttribute("ConsNumObj", consumerNumber);
							session.setAttribute("UnitConsObj", unitsconsumed);
							session.setAttribute("NetAmtObj", netAmount);
							rdSuccess.forward(request, response);
						}
						else
						{
							String msg="Invalid Consumer Number!";
							request.setAttribute("ErrorMsgObj", msg);
							rd=request.getRequestDispatcher("Login.html");
							rd.forward(request, response);
						}
						
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
					}
				}
				/********End ShowLastPage**************/
				
			}
			catch(Exception e)
			{
				String erMsg = e.getMessage();
				request.setAttribute("ErrorMsgObj", erMsg);
				
//				RequestDispatcher rdError = request.getRequestDispatcher("ShowErrorPage");
//				rdError.forward(request, response);
			}
			
		}
		else
		{
			response.getWriter().println(" No Action Defined.");
		}
	}

}
