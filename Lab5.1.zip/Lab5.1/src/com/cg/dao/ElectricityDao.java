package com.cg.dao;

import java.sql.SQLException;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;


public interface ElectricityDao 
{
	public int insertDetails(BillDetails bills) throws SQLException; 
	public int generatebill_id() throws SQLException;
	public int checkCons(BillDetails bills) throws Exception;
}
