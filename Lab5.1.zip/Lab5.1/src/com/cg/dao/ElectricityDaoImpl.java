package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.util.DBUtil;

public class ElectricityDaoImpl implements ElectricityDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	
	

	@Override
	public int insertDetails(BillDetails bills) throws SQLException 
	{
		int data;
		con=DBUtil.getCon();
		System.out.println(" Got Connection :");
		String qry="Insert into billdetails values(?,?,?,?,?,sysdate)";
		pst=con.prepareStatement(qry);
		pst.setInt(1, generatebill_id());
		pst.setInt(2,bills.getConsumer_num());
		pst.setFloat(3,bills.getCur_reading());
		pst.setInt(4,bills.getUnitConsumed());
		pst.setDouble(5,bills.getNetAmount());
		data=pst.executeUpdate();
		
		return data;
	}



	@Override
	public int generatebill_id() throws SQLException {
		int generatedVal = 0;
		String qry="SELECT seq_bill_num.NEXTVAL "
				+ " FROM DUAL";
		try 
		{
			con=DBUtil.getCon();
			System.out.println(con);
			st=con.createStatement();
			rs=st.executeQuery(qry);

			rs.next();

			generatedVal=rs.getInt(1);

		} 
		catch (Exception e) 
		{

			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}		
		} 
		finally
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{	
				try {
					throw new Exception(e.getMessage());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}		
			}

		}
		return generatedVal;
	}



	@Override
	public int checkCons(BillDetails bills) throws Exception {
		
		int data;
		String qry = "select consumer_name from consumers WHERE consumer_num=?";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry); 
			pst.setInt(1, bills.getConsumer_num());
			
			data=pst.executeUpdate();
			//empLogger.log(Level.INFO,"Emp Inserted: "+emp);
			
		} 
		catch (Exception e) 
		{
			throw new Exception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				//empLogger.error("This is Exception: " +e.getMessage());
				throw new Exception(e.getMessage());
				//not printing sop instead wrapping the SQLException in EmployeeException
				//and then throwing EmployeeException coz we have defined that exception.
			}
		}
		
		return data;
		
	}

}
