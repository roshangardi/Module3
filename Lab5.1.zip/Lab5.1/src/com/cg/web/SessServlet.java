package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.service.ElectricityService;
import com.cg.service.ElectricityServiceImpl;


@WebServlet("/SessServlet")
public class SessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ElectricityService eleserv=null;
	Consumers cons=null;
	BillDetails bills =null;
       
    
    public SessServlet() {
        super();
   
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}


	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		eleserv = new ElectricityServiceImpl();
		cons = new Consumers();
		bills = new BillDetails();
		
		PrintWriter out = response.getWriter();
		
		String consu = request.getParameter("cnum");
		int consumerNumber=Integer.parseInt(consu);
		String lread = request.getParameter("lastReading");
		int lastReading=Integer.parseInt(lread);
		String cread = request.getParameter("currentReading");
		int currReading=Integer.parseInt(cread);
		
		int unitsconsumed = lastReading-currReading;
		double netAmount = (unitsconsumed *1.15)+100;
		
		bills.setConsumer_num(consumerNumber);
		bills.setCur_reading(currReading);
		bills.setNetAmount(netAmount);
		bills.setUnitConsumed(unitsconsumed);
		
		try 
		{
			if(eleserv.insertDetails(bills) == 1)
			{
				out.println("Registration done!!!");
			}
			else
			{
				out.println("Registration Failed");
			}
			
			if(eleserv.checkCons(bills)==1)
			{
				
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
