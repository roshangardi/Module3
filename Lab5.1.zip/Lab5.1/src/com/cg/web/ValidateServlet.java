package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.cg.service.ElectricityService;
import com.cg.service.ElectricityServiceImpl;



@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet 
{
	ElectricityService eleserv=null;
	
	private static final long serialVersionUID = 1L;
       
   
    public ValidateServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Init of ValidateServlet");
	}


	public void destroy() {
		System.out.println("Destroy of ValidateServlet");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw = response.getWriter();
		eleserv = new ElectricityServiceImpl();
		String unm = request.getParameter("txtUName");
		String pwd = request.getParameter("txtPwd");
		
		try 
		{
			
			if(unm.equals("admin") && pwd.equals("admin"))
			{
				RequestDispatcher rdSuccess = request.getRequestDispatcher("User_info.html");//forwarding to new servlet(dynamic page).
				rdSuccess.forward(request, response);
			}
			else
			{
				//RequestDispatcher rdFailure = request.getRequestDispatcher("htmls/Failure.html");//forwarding new html page(static page).
				//Instead of forwarding to failure page forward to login page.
				RequestDispatcher rdFailure = request.getRequestDispatcher("htmls/Login.html");
				rdFailure.forward(request, response);
			}
		} 
		catch (Exception e) 
		{			
			e.printStackTrace();
		}
	}

}
