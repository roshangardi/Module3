package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumers;
import com.cg.dao.ElectricityDao;
import com.cg.dao.ElectricityDaoImpl;

public class ElectricityServiceImpl implements ElectricityService
{
	ElectricityDao elecd=null;
	
	public ElectricityServiceImpl()
	{
		elecd = new ElectricityDaoImpl();
	}

	@Override
	public int insertDetails(BillDetails bills) throws SQLException {
		return elecd.insertDetails(bills);
	}

	@Override
	public int generatebill_id() throws SQLException {
		
		return elecd.generatebill_id();
	}

	@Override
	public int checkCons(BillDetails bills) throws Exception {
		
		return elecd.checkCons(bills);
	}


}
