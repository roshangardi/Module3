package com.student.exception;

public class StudentException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1324579236684138925L;

	public StudentException(String message)
	{
		super(message);
	}
}
