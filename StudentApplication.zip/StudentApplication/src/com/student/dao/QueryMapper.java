package com.student.dao;

public interface QueryMapper {
	
	public static final String viewAll= "select studentroll,studentname,dob from student";

}
