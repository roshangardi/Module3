package com.cg.banking.service;


import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.dao.AccountDAOImpl;
import com.cg.banking.dao.IAccountDAO;
import com.cg.banking.exception.AccountException;

public class AccountServiceImpl implements IAccountService {
	IAccountDAO dao = new AccountDAOImpl();
	@Override
	public List<BankingBean> getAccount(String customer_name) throws AccountException {
       
	
		return dao.getAccount(customer_name);
	}
	@Override
	public BankingBean updateTransaction(String account_number,float amount)	throws AccountException {
		BankingBean bankBean = new BankingBean();
		float balance=dao.getBalance(account_number);
		if(amount<balance){
			balance=balance-amount;
			if(dao.updateBalance(account_number,balance)){
				boolean isInserted=dao.insertTransaction(account_number,amount);
				if(isInserted){
					
					bankBean.setAccount_number(account_number);
					bankBean.setBalance(balance);
				}
				else{
					throw new AccountException("Not Inserted");
				}
			}
			else{
				throw new AccountException("Balance Not Updated");
			}
		}
		else 
		{
			throw new AccountException("Insufficient Balance");
		}
		
		
		return bankBean;
	}
	
}
