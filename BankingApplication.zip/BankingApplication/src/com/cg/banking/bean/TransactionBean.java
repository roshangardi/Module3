package com.cg.banking.bean;

import java.time.LocalDate;

public class TransactionBean {
	private int transaction_id;
	private String 	transaction_description; 
	private float transaction_amount; 
	private LocalDate transaction_date ;
	private String account_number;
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_description() {
		return transaction_description;
	}
	public void setTransaction_description(String transaction_description) {
		this.transaction_description = transaction_description;
	}
	public float getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(float transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	public LocalDate getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(LocalDate transaction_date) {
		this.transaction_date = transaction_date;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	/**
	 * 
	 */
	public TransactionBean() {
		super();
	}
	/**
	 * @param transaction_id
	 * @param transaction_description
	 * @param transaction_amount
	 * @param transaction_date
	 * @param account_number
	 */
	public TransactionBean(int transaction_id, String transaction_description,
			float transaction_amount, LocalDate transaction_date,
			String account_number) {
		super();
		this.transaction_id = transaction_id;
		this.transaction_description = transaction_description;
		this.transaction_amount = transaction_amount;
		this.transaction_date = transaction_date;
		this.account_number = account_number;
	}
	@Override
	public String toString() {
		return "TransactionBean [transaction_id=" + transaction_id
				+ ", transaction_description=" + transaction_description
				+ ", transaction_amount=" + transaction_amount
				+ ", transaction_date=" + transaction_date
				+ ", account_number=" + account_number + "]";
	}
	
}
