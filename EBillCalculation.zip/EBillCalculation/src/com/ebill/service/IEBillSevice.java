package com.ebill.service;

import java.util.List;

import com.ebill.bean.EBillBean;
import com.ebill.exception.EBillException;

public interface IEBillSevice {
  public List<EBillBean> viewAllBillDetails() throws EBillException;
}
