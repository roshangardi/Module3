package com.ebill.bean;

public class EBillBean {
	     private int consumerNumber;
         private String consumerName;
         private String consumerAddress;
		
         public EBillBean() {
			super();
		}

		public EBillBean(int consumerNumber, String consumerName,
				String consumerAddress) {
			super();
			this.consumerNumber = consumerNumber;
			this.consumerName = consumerName;
			this.consumerAddress = consumerAddress;
		}

		public int getConsumerNumber() {
			return consumerNumber;
		}

		public void setConsumerNumber(int consumerNumber) {
			this.consumerNumber = consumerNumber;
		}

		public String getConsumerName() {
			return consumerName;
		}

		public void setConsumerName(String consumerName) {
			this.consumerName = consumerName;
		}

		public String getConsumerAddress() {
			return consumerAddress;
		}

		public void setConsumerAddress(String consumerAddress) {
			this.consumerAddress = consumerAddress;
		}

		@Override
		public String toString() {
			return "EBillBean [consumerNumber=" + consumerNumber
					+ ", consumerName=" + consumerName + ", consumerAddress="
					+ consumerAddress + "]";
		}
         
         
         
         
}
