package com.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ebill.bean.EBillBean;
import com.ebill.dbutil.DbConnection;
import com.ebill.exception.EBillException;

public class EBillDaoImpl implements IEBillDao{

	@Override
	public List<EBillBean> viewAllBillDetails() throws EBillException {
		List<EBillBean> list = new ArrayList<EBillBean>();
		
	 Connection con = null;
	 
		try {
			con=DbConnection.getConnection();
			 PreparedStatement pstm = con.prepareStatement(QueryMapper.viewAll);
			 
			 ResultSet rs = pstm.executeQuery();
			 
			 while(rs.next())
			 {
				 EBillBean bean = new EBillBean();
				 bean.setConsumerNumber(rs.getInt(1));
				 bean.setConsumerName(rs.getString(2));
				 bean.setConsumerAddress(rs.getString(3));
				 
				 list.add(bean);
			 }
			 
			 con.close();
		} catch (SQLException e) {
			
		}
	

		return list;
	}

}
