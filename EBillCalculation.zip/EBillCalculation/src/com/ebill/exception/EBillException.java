package com.ebill.exception;

public class EBillException extends Exception {
   public EBillException(String message){
	   super(message);
   }
}
