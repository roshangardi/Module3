package com.cg.ebill.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.cg.ebill.exception.EbillException;

public class DBConnection {
	private static Connection con=null;
	public static Connection getConnection() throws EbillException{
		InitialContext context;
		try{
			if(con==null){
				context= new InitialContext();
				DataSource dataSource=(DataSource)context.lookup("java:/OracleDS");
				con=dataSource.getConnection();
				con.setAutoCommit(false);
				System.out.println(con);
				System.out.println("Connection Successfull");
			}
		}catch(SQLException | NamingException e){
			throw new EbillException("Connection to database failed!!");
		}
		return con;
	}


}
