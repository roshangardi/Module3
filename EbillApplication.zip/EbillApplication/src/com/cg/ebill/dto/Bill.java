package com.cg.ebill.dto;

import java.io.Serializable;
import java.time.LocalDate;

@SuppressWarnings("serial")
public class Bill implements Serializable{
	private int billNum;
	private int consumerNum;
	private float currentReading;
	private float unitConsumed;
	private float netAmount;
	private LocalDate billDate;
	public int getBillNum() {
		return billNum;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public float getCurrentReading() {
		return currentReading;
	}
	public float getUnitConsumed() {
		return unitConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public void setCurrentReading(float currentReading) {
		this.currentReading = currentReading;
	}
	public void setUnitConsumed(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public void setNetAmount(float unitConsumed) {
		this.netAmount = (float)(unitConsumed*1.15)+100;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}
	@Override
	public String toString() {
		return "Bill [billNum=" + billNum + ", consumerNum=" + consumerNum
				+ ", currentReading=" + currentReading + ", unitConsumed="
				+ unitConsumed + ", netAmount=" + netAmount + ", billDate="
				+ billDate + "]";
	}

}
