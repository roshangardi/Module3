package com.cg.ebill.dto;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Consumer implements Serializable{
	private int consumerNum;
	private String consumerName;
	private String consumerAddress;
	public int getConsumerNum() {
		return consumerNum;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public String getConsumerAddress() {
		return consumerAddress;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public void setConsumerAddress(String consumerAddress) {
		this.consumerAddress = consumerAddress;
	}
	@Override
	public String toString() {
		return "Consumer [consumerNum=" + consumerNum + ", consumerName="
				+ consumerName + ", consumerAddress=" + consumerAddress + "]";
	}

}
